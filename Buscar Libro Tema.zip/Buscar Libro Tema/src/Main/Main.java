package Main;

import Methods.*;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author lokci
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int opc;
        String name, theme;
        libros book;
        ArrayList<String> list;
        list = new ArrayList<String>();
        ArrayList<libros> libros;
        libros = new ArrayList<libros>();
        buscarLibroTema search;
        search = new buscarLibroTema(libros);

        Scanner in = new Scanner(System.in);

        System.out.println("Bueno papi, ingrese libros que quiere registrar.");
        System.out.println("Ingrese el nombre: ");
        name = in.next();
        System.out.println("Ingrese el tema: ");
        theme = in.next();
        book = new libros(name, theme);
        search.agregaLibros(book);

        do {
            System.out.println("Qué desea realizar: "
                    + "1. Buscar libro por tema."
                    + "2. Agregar libro.");

            opc = in.nextInt();

            switch (opc) {
                case 1:
                    System.out.println("Ingrese el tema a buscar");
                    theme = in.next();

                    list.add(search.iteradorLibros(theme));
                    System.out.println(list);
                    break;
                case 2:
                    System.out.println("Ingrese el nombre: ");
                    name = in.next();
                    System.out.println("Ingrese el tema: ");
                    theme = in.next();
                    book = new libros(name, theme);
                    search.agregaLibros(book);

            }
        } while (true);

    }

}
