package Methods;

import java.util.ArrayList;

/**
 *
 * @author lokci
 */
public class buscarLibroTema {

    private int ocurrencias;
    private String bookIs;
    ArrayList<libros> libros;

    public buscarLibroTema(ArrayList<libros> libros) {
        this.libros = libros;
    }        
                
    public void agregaLibros(libros libro){
        libros.add(libro);
    }

    public String iteradorLibros(String tema) {        
        for (libros libro : libros) {
            if (tema.equals(libro.getTema())) {    
                bookIs = libro.getNombre();
                ocurrencias++;                
                return bookIs;
            }
        }
        return "";
    }

    public int getOcurrencias() {
        return ocurrencias;
    }

}
