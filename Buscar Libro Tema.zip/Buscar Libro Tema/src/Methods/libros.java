package Methods;

/**
 *
 * @author lokci
 */
public class libros {
    
    private String nombre;
    private String tema;

    public libros(String nombre, String tema) {
        this.nombre = nombre;
        this.tema = tema;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTema() {
        return tema;
    }    
    
    @Override
    public String toString() {
        return "Libros{" + "nombre=" + nombre + ", tema=" + tema + '}';
    }        
    
}
